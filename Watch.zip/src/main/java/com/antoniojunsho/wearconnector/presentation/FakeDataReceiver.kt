package com.antoniojunsho.wearconnector.presentation

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.location.Location
import android.util.Log
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.time.Instant
import kotlin.random.Random
import android.widget.Toast

class FakeDataReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        Toast.makeText(context, "Broadcast recebido!", Toast.LENGTH_LONG).show()
        Log.d("FakeDataReceiver", "Broadcast recebido")

        val fakeLat = Random.nextDouble(-90.0, 90.0)
        val fakeLon = Random.nextDouble(-180.0, 180.0)
        val fakeHR = Random.nextInt(50, 120).toFloat()

        val location = Location("").apply {
            latitude = fakeLat
            longitude = fakeLon
        }

        val ip = context.getSharedPreferences("config", Context.MODE_PRIVATE)
            .getString("server_ip", null)

        if (!ip.isNullOrBlank()) {
            sendData(ip, location, fakeHR)
        } else {
            Log.e("FakeDataReceiver", "IP do servidor não configurado.")
        }
    }

    private fun sendData(ip: String, location: Location, hr: Float) {
        val client = OkHttpClient()
        val json = JSONObject().apply {
            put("lat", location.latitude)
            put("lon", location.longitude)
            put("heartrate", hr)
            put("timestamp", Instant.now().toString())
        }

        val body = json.toString()
            .toRequestBody("application/json".toMediaType())

        val request = Request.Builder()
            .url("http://$ip/wear")
            .post(body)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e("FakeDataReceiver", "Erro ao enviar: ${e.message}")
            }

            override fun onResponse(call: Call, response: Response) {
                Log.d("FakeDataReceiver", "Enviado! Status: ${response.code}")
            }
        })
    }
}

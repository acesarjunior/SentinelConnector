package com.antoniojunsho.wearconnector.presentation

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.antoniojunsho.wearconnector.presentation.theme.WearConnectorTheme
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.time.Instant
import kotlin.random.Random
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


class MainActivity : ComponentActivity(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private var heartRate: Float? = null
    private lateinit var fusedLocationClient: FusedLocationProviderClient

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager

        requestPermissions()

        setContent {
            WearConnectorTheme {
                IPConfigScreen()
            }
        }

        val hrSensor = sensorManager.getDefaultSensor(Sensor.TYPE_HEART_RATE)
        if (hrSensor != null) {
            sensorManager.registerListener(this, hrSensor, SensorManager.SENSOR_DELAY_NORMAL)
        }
    }

    private fun requestPermissions() {
        val permissions = listOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.BODY_SENSORS
        )

        val toRequest = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (toRequest.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, toRequest.toTypedArray(), 1)
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event?.sensor?.type == Sensor.TYPE_HEART_RATE) {
            heartRate = event.values[0]
            tryToSendData()
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun tryToSendData() {
        val ip = getSharedPreferences("config", MODE_PRIVATE).getString("server_ip", null)
        if (ip.isNullOrBlank()) return

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) return

        fusedLocationClient.lastLocation
            .addOnSuccessListener { location: Location? ->
                if (location != null && heartRate != null) {
                    sendData(ip, location, heartRate!!)
                }
            }
    }

    fun sendData(ip: String, location: Location, hr: Float) {
        val client = OkHttpClient()
        val json = JSONObject()
        json.put("lat", location.latitude)
        json.put("lon", location.longitude)
        json.put("heartrate", hr)
        json.put("timestamp", Instant.now().toString())

        val body = json.toString()
            .toRequestBody("application/json".toMediaType())

        val request = Request.Builder()
            .url("http://$ip/wear")
            .post(body)
            .build()

        client.newCall(request).execute().use {
            Log.d("SEND", "Dados enviados: ${it.code}")
        }
    }

    fun sendDummyData() {
        val fakeLat = Random.nextDouble(-90.0, 90.0)
        val fakeLon = Random.nextDouble(-180.0, 180.0)
        val fakeHR = Random.nextInt(50, 130).toFloat()

        val location = Location("").apply {
            latitude = fakeLat
            longitude = fakeLon
        }

        val ip = getSharedPreferences("config", MODE_PRIVATE).getString("server_ip", null)
        if (!ip.isNullOrBlank()) {
            lifecycleScope.launch {
                withContext(Dispatchers.IO) {
                    sendData(ip, location, fakeHR)
                }
            }
        }
    }
}

@Composable
fun IPConfigScreen() {
    val context = LocalContext.current
    val sharedPreferences = context.getSharedPreferences("config", ComponentActivity.MODE_PRIVATE)
    var ipText by remember {
        mutableStateOf(TextFieldValue(sharedPreferences.getString("server_ip", "") ?: ""))
    }
    var statusMessage by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "Servidor IP:")
        TextField(
            value = ipText,
            onValueChange = { ipText = it },
            modifier = Modifier.fillMaxWidth()
        )
        Button(
            onClick = {
                val ip = ipText.text.trim()
                if (ip.isNotEmpty()) {
                    sharedPreferences.edit().putString("server_ip", ip).apply()
                    statusMessage = "IP salvo: $ip"

                    // 👇 Adicione este log:
                    Log.d("IPConfigScreen", "IP salvo: $ip")
                } else {
                    statusMessage = "Digite um IP válido"
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Salvar")
        }

        Button(
            onClick = {
                (context as? MainActivity)?.sendDummyData()
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Enviar dados fake")
        }

        if (statusMessage.isNotEmpty()) {
            Text(text = statusMessage)
        }
    }
}
